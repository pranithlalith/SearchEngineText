﻿namespace SearchEngineText
{
    partial class frmSearchSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.PnlMain = new System.Windows.Forms.Panel();
            this.tblPnlIndexerMain = new System.Windows.Forms.TableLayoutPanel();
            this.tblPnlFilSelection = new System.Windows.Forms.TableLayoutPanel();
            this.lblSelectFile = new System.Windows.Forms.Label();
            this.lnklblUploadSearch = new System.Windows.Forms.LinkLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnlSearchMain = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.PnlSearch = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxSearchWord = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvSearchresults = new System.Windows.Forms.DataGridView();
            this.gcolFileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gColCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnUpload = new System.Windows.Forms.Button();
            this.lblIndexer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PnlFile = new System.Windows.Forms.Panel();
            this.pnlFolder = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.lnkLabelFolder = new System.Windows.Forms.LinkLabel();
            this.btnUploadFolder = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lnkConditionalSearch = new System.Windows.Forms.LinkLabel();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.lblMessage = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.PnlMain.SuspendLayout();
            this.tblPnlIndexerMain.SuspendLayout();
            this.tblPnlFilSelection.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlSearchMain.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.PnlSearch.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchresults)).BeginInit();
            this.PnlFile.SuspendLayout();
            this.pnlFolder.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(941, 521);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.PnlMain);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(933, 488);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Indexer";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // PnlMain
            // 
            this.PnlMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlMain.Controls.Add(this.tblPnlIndexerMain);
            this.PnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlMain.Location = new System.Drawing.Point(0, 0);
            this.PnlMain.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.PnlMain.Name = "PnlMain";
            this.PnlMain.Size = new System.Drawing.Size(933, 488);
            this.PnlMain.TabIndex = 0;
            // 
            // tblPnlIndexerMain
            // 
            this.tblPnlIndexerMain.BackColor = System.Drawing.Color.Beige;
            this.tblPnlIndexerMain.ColumnCount = 1;
            this.tblPnlIndexerMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlIndexerMain.Controls.Add(this.lblIndexer, 0, 1);
            this.tblPnlIndexerMain.Controls.Add(this.PnlFile, 0, 2);
            this.tblPnlIndexerMain.Controls.Add(this.pnlFolder, 0, 3);
            this.tblPnlIndexerMain.Controls.Add(this.btnClose, 0, 6);
            this.tblPnlIndexerMain.Controls.Add(this.lblMessage, 0, 5);
            this.tblPnlIndexerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlIndexerMain.Location = new System.Drawing.Point(0, 0);
            this.tblPnlIndexerMain.Margin = new System.Windows.Forms.Padding(0);
            this.tblPnlIndexerMain.Name = "tblPnlIndexerMain";
            this.tblPnlIndexerMain.RowCount = 7;
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tblPnlIndexerMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tblPnlIndexerMain.Size = new System.Drawing.Size(931, 486);
            this.tblPnlIndexerMain.TabIndex = 0;
            // 
            // tblPnlFilSelection
            // 
            this.tblPnlFilSelection.ColumnCount = 4;
            this.tblPnlFilSelection.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 174F));
            this.tblPnlFilSelection.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 238F));
            this.tblPnlFilSelection.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147F));
            this.tblPnlFilSelection.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlFilSelection.Controls.Add(this.lblSelectFile, 0, 0);
            this.tblPnlFilSelection.Controls.Add(this.lnklblUploadSearch, 1, 0);
            this.tblPnlFilSelection.Controls.Add(this.btnUpload, 2, 0);
            this.tblPnlFilSelection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlFilSelection.Location = new System.Drawing.Point(0, 0);
            this.tblPnlFilSelection.Margin = new System.Windows.Forms.Padding(0);
            this.tblPnlFilSelection.Name = "tblPnlFilSelection";
            this.tblPnlFilSelection.RowCount = 1;
            this.tblPnlFilSelection.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlFilSelection.Size = new System.Drawing.Size(909, 30);
            this.tblPnlFilSelection.TabIndex = 0;
            // 
            // lblSelectFile
            // 
            this.lblSelectFile.AutoSize = true;
            this.lblSelectFile.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblSelectFile.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectFile.Location = new System.Drawing.Point(6, 0);
            this.lblSelectFile.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSelectFile.Name = "lblSelectFile";
            this.lblSelectFile.Size = new System.Drawing.Size(131, 30);
            this.lblSelectFile.TabIndex = 0;
            this.lblSelectFile.Text = "Choose File :";
            this.lblSelectFile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lnklblUploadSearch
            // 
            this.lnklblUploadSearch.AutoSize = true;
            this.lnklblUploadSearch.Dock = System.Windows.Forms.DockStyle.Left;
            this.lnklblUploadSearch.Location = new System.Drawing.Point(180, 0);
            this.lnklblUploadSearch.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lnklblUploadSearch.Name = "lnklblUploadSearch";
            this.lnklblUploadSearch.Size = new System.Drawing.Size(71, 30);
            this.lnklblUploadSearch.TabIndex = 1;
            this.lnklblUploadSearch.TabStop = true;
            this.lnklblUploadSearch.Text = "Browse";
            this.lnklblUploadSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnklblUploadSearch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pnlSearchMain);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(933, 488);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Search";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlSearchMain
            // 
            this.pnlSearchMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearchMain.Controls.Add(this.tableLayoutPanel2);
            this.pnlSearchMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearchMain.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchMain.Margin = new System.Windows.Forms.Padding(0);
            this.pnlSearchMain.Name = "pnlSearchMain";
            this.pnlSearchMain.Size = new System.Drawing.Size(933, 488);
            this.pnlSearchMain.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Beige;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.PnlSearch, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.dgvSearchresults, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.button2, 0, 4);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(931, 486);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // PnlSearch
            // 
            this.PnlSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlSearch.Controls.Add(this.tableLayoutPanel3);
            this.PnlSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlSearch.Location = new System.Drawing.Point(10, 55);
            this.PnlSearch.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.PnlSearch.Name = "PnlSearch";
            this.PnlSearch.Size = new System.Drawing.Size(911, 35);
            this.PnlSearch.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 344F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtBoxSearchWord, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnSearch, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.lnkConditionalSearch, 3, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(909, 33);
            this.tableLayoutPanel3.TabIndex = 0;
            this.tableLayoutPanel3.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel3_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Keyword :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtBoxSearchWord
            // 
            this.txtBoxSearchWord.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtBoxSearchWord.Location = new System.Drawing.Point(138, 2);
            this.txtBoxSearchWord.Margin = new System.Windows.Forms.Padding(0);
            this.txtBoxSearchWord.Name = "txtBoxSearchWord";
            this.txtBoxSearchWord.Size = new System.Drawing.Size(334, 28);
            this.txtBoxSearchWord.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSearch.Location = new System.Drawing.Point(482, 0);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(0);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 33);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvSearchresults
            // 
            this.dgvSearchresults.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSearchresults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearchresults.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gcolFileName,
            this.gColCount});
            this.dgvSearchresults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSearchresults.Location = new System.Drawing.Point(10, 90);
            this.dgvSearchresults.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.dgvSearchresults.Name = "dgvSearchresults";
            this.dgvSearchresults.RowTemplate.Height = 24;
            this.dgvSearchresults.Size = new System.Drawing.Size(911, 366);
            this.dgvSearchresults.TabIndex = 1;
            // 
            // gcolFileName
            // 
            this.gcolFileName.DataPropertyName = "Key";
            this.gcolFileName.HeaderText = "File Name";
            this.gcolFileName.Name = "gcolFileName";
            this.gcolFileName.Width = 114;
            // 
            // gColCount
            // 
            this.gColCount.DataPropertyName = "Value";
            this.gColCount.HeaderText = "Count";
            this.gColCount.Name = "gColCount";
            this.gColCount.Width = 89;
            // 
            // btnUpload
            // 
            this.btnUpload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUpload.Enabled = false;
            this.btnUpload.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.Location = new System.Drawing.Point(412, 0);
            this.btnUpload.Margin = new System.Windows.Forms.Padding(0);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(147, 30);
            this.btnUpload.TabIndex = 2;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // lblIndexer
            // 
            this.lblIndexer.AutoSize = true;
            this.lblIndexer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(193)))));
            this.lblIndexer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndexer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIndexer.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndexer.Location = new System.Drawing.Point(10, 20);
            this.lblIndexer.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblIndexer.Name = "lblIndexer";
            this.lblIndexer.Size = new System.Drawing.Size(911, 32);
            this.lblIndexer.TabIndex = 1;
            this.lblIndexer.Text = "Indexer";
            this.lblIndexer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(193)))));
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(911, 35);
            this.label2.TabIndex = 2;
            this.label2.Text = "Search";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PnlFile
            // 
            this.PnlFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlFile.Controls.Add(this.tblPnlFilSelection);
            this.PnlFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PnlFile.Location = new System.Drawing.Point(10, 52);
            this.PnlFile.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.PnlFile.Name = "PnlFile";
            this.PnlFile.Size = new System.Drawing.Size(911, 32);
            this.PnlFile.TabIndex = 2;
            // 
            // pnlFolder
            // 
            this.pnlFolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlFolder.Controls.Add(this.tableLayoutPanel4);
            this.pnlFolder.Location = new System.Drawing.Point(10, 84);
            this.pnlFolder.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.pnlFolder.Name = "pnlFolder";
            this.pnlFolder.Size = new System.Drawing.Size(911, 32);
            this.pnlFolder.TabIndex = 3;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 4;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 174F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 238F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 147F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.lnkLabelFolder, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnUploadFolder, 2, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(909, 30);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 30);
            this.label3.TabIndex = 0;
            this.label3.Text = "Choose Folder :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lnkLabelFolder
            // 
            this.lnkLabelFolder.AutoSize = true;
            this.lnkLabelFolder.Dock = System.Windows.Forms.DockStyle.Left;
            this.lnkLabelFolder.Location = new System.Drawing.Point(180, 0);
            this.lnkLabelFolder.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lnkLabelFolder.Name = "lnkLabelFolder";
            this.lnkLabelFolder.Size = new System.Drawing.Size(71, 30);
            this.lnkLabelFolder.TabIndex = 1;
            this.lnkLabelFolder.TabStop = true;
            this.lnkLabelFolder.Text = "Browse";
            this.lnkLabelFolder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkLabelFolder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // btnUploadFolder
            // 
            this.btnUploadFolder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUploadFolder.Enabled = false;
            this.btnUploadFolder.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUploadFolder.Location = new System.Drawing.Point(412, 0);
            this.btnUploadFolder.Margin = new System.Windows.Forms.Padding(0);
            this.btnUploadFolder.Name = "btnUploadFolder";
            this.btnUploadFolder.Size = new System.Drawing.Size(147, 30);
            this.btnUploadFolder.TabIndex = 2;
            this.btnUploadFolder.Text = "Upload";
            this.btnUploadFolder.UseVisualStyleBackColor = true;
            this.btnUploadFolder.Click += new System.EventHandler(this.btnUploadFolder_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnClose.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(403, 451);
            this.btnClose.Margin = new System.Windows.Forms.Padding(0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(125, 35);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.button2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(403, 456);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 30);
            this.button2.TabIndex = 5;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lnkConditionalSearch
            // 
            this.lnkConditionalSearch.AutoSize = true;
            this.lnkConditionalSearch.Dock = System.Windows.Forms.DockStyle.Left;
            this.lnkConditionalSearch.Location = new System.Drawing.Point(582, 0);
            this.lnkConditionalSearch.Margin = new System.Windows.Forms.Padding(0);
            this.lnkConditionalSearch.Name = "lnkConditionalSearch";
            this.lnkConditionalSearch.Size = new System.Drawing.Size(165, 33);
            this.lnkConditionalSearch.TabIndex = 3;
            this.lnkConditionalSearch.TabStop = true;
            this.lnkConditionalSearch.Text = "ConditionalSearch";
            this.lnkConditionalSearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lnkConditionalSearch.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkConditionalSearch_LinkClicked);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMessage.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(10, 416);
            this.lblMessage.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(911, 35);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "The files are being uploaded please wait";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMessage.Visible = false;
            // 
            // frmSearchSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(941, 521);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "frmSearchSystem";
            this.Text = "Search System";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.PnlMain.ResumeLayout(false);
            this.tblPnlIndexerMain.ResumeLayout(false);
            this.tblPnlIndexerMain.PerformLayout();
            this.tblPnlFilSelection.ResumeLayout(false);
            this.tblPnlFilSelection.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.pnlSearchMain.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.PnlSearch.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchresults)).EndInit();
            this.PnlFile.ResumeLayout(false);
            this.pnlFolder.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel PnlMain;
        private System.Windows.Forms.TableLayoutPanel tblPnlIndexerMain;
        private System.Windows.Forms.TableLayoutPanel tblPnlFilSelection;
        private System.Windows.Forms.Label lblSelectFile;
        private System.Windows.Forms.LinkLabel lnklblUploadSearch;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel pnlSearchMain;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel PnlSearch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxSearchWord;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvSearchresults;
        private System.Windows.Forms.DataGridViewTextBoxColumn gcolFileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn gColCount;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Label lblIndexer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel PnlFile;
        private System.Windows.Forms.Panel pnlFolder;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.LinkLabel lnkLabelFolder;
        private System.Windows.Forms.Button btnUploadFolder;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.LinkLabel lnkConditionalSearch;
        private System.Windows.Forms.Label lblMessage;
    }
}

