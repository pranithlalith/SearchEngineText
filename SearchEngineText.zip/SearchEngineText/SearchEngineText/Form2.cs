﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SearchEngineText
{
    public partial class searchBox : Form
    {
        public searchBox()
        {
            InitializeComponent();
            cmbType.Text = "<--Select-->";
            cmbSearchType.Text = "EXACT";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (cmbType.Text.Equals("<--Select-->"))
            {
                MessageBox.Show("PLease select a search criteria");
                return;
            }
            frmSearchSystem.sSearchInput.Clear();
            frmSearchSystem.sSearchType = cmbType.Text;
            frmSearchSystem.sSearhExact = cmbSearchType.Text;
            foreach (string str in txtBoxSearch.Lines)
            {
                frmSearchSystem.sSearchInput.Add(str);
            }
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
