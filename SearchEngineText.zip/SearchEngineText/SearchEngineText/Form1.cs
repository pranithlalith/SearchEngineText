﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace SearchEngineText
{
    public partial class frmSearchSystem : Form
    {
        public Dictionary<string, Dictionary<string, int>> dictWords = new Dictionary<string, Dictionary<string, int>>();
        private BinaryFormatter formatter = new BinaryFormatter();
        public const string DATA_FILENAME = "index.dat";
        public Dictionary<string, int> dictResults = new Dictionary<string, int>();
        public List<KeyValuePair<string, int>> lstResults = new List<KeyValuePair<string, int>>();
        public static List<string> sSearchInput = new List<string>();
        public static string sSearchType = string.Empty;
        public static string sSearhExact = string.Empty;
        public List<string> lstFinalResults = new List<string>();
        public DataTable dtFinalResults = null;
        public string sSelectedFolder = string.Empty;
        public frmSearchSystem()
        {
            InitializeComponent();
            LoadIndexFile();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string sFileName = string.Empty;
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select file to be Uploaded";
            openFileDialog.Filter = "*.txt|*.TXT";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                openFileDialog.AddExtension = true;
                openFileDialog.CheckFileExists = true;
                openFileDialog.CheckPathExists = true;
                if (openFileDialog.FileName != "")
                {
                    sFileName = openFileDialog.FileName.Substring(openFileDialog.FileName.LastIndexOf(@"\") + 1, openFileDialog.FileName.Length - 1 - openFileDialog.FileName.LastIndexOf(@"\"));
                    lnklblUploadSearch.Text = sFileName;
                    lnklblUploadSearch.Links[0].LinkData = openFileDialog.FileName;
                    lnklblUploadSearch.AutoSize = true;
                    btnUpload.Enabled = true;
                }
                else
                {
                    btnUpload.Enabled = false;
                }
            }
            else
            {
                btnUpload.Enabled = false;
            }

        }

        private void SaveIndexFile()
        {
            try
            {
                FileStream writerFileStream = new FileStream(DATA_FILENAME, FileMode.Create, FileAccess.Write);
                this.formatter.Serialize(writerFileStream, dictWords);
                writerFileStream.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void LoadIndexFile()
        {
            if (File.Exists(DATA_FILENAME))
            {
                try
                {

                    FileStream readerFileStream = new FileStream(DATA_FILENAME, FileMode.Open, FileAccess.Read);
                    dictWords = (Dictionary<String, Dictionary<string, int>>)this.formatter.Deserialize(readerFileStream);

                    readerFileStream.Close();

                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }

        }

        static string[] SplitWords(string s)
        {
            return Regex.Split(s, @"\W+");

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sQueryInput = txtBoxSearchWord.Text;
            GenerateSearchResults(sQueryInput);
        }

        private void GenerateSearchResults(string sQuery)
        {
            try
            {
                dgvSearchresults.DataSource = null;


                if (dictWords.ContainsKey(sQuery))
                {
                    dictResults = new Dictionary<string, int>();
                    dictResults = dictWords[sQuery];
                    lstResults = dictResults.ToList();
                    var queryList = from lst in lstResults.AsEnumerable()
                                    orderby lst.Value descending
                                    select new
                                    {
                                        KEY = lst.Key.ToString(),
                                        Value = Convert.ToInt32(lst.Value)
                                    };
                    dgvSearchresults.DataSource = queryList.ToList();
                    gcolFileName.HeaderText = "File Name";
                    gColCount.HeaderText = "Count";

                }
                else
                {
                    MessageBox.Show("No Matches Found");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message.ToString());
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "The File(s) are being scanned, please wait";
            lblMessage.ForeColor = Color.Red;
            lblMessage.Visible = true;
            string[] contents = SplitWords(System.IO.File.ReadAllText(lnklblUploadSearch.Links[0].LinkData.ToString()));
            Dictionary<string, int> dictFileName = new Dictionary<string, int>();
            var wordsCounts = from word in contents
                              group word by word.ToLower()
                               into g
                              select new { Word = g.Key, Count = g.Count() };
            Dictionary<string, int> dictFileWords = wordsCounts.ToDictionary(wc => wc.Word, wc => wc.Count);
            foreach (string sWord in dictFileWords.Keys)
            {
                int iCountValue = dictFileWords[sWord];
                if (!dictWords.ContainsKey(sWord))
                {

                    dictFileName = new Dictionary<string, int>();
                    dictFileName.Add(lnklblUploadSearch.Text, iCountValue);
                    dictWords.Add(sWord, dictFileName);
                }
                else
                {
                    dictWords[sWord].Add(lnklblUploadSearch.Text, iCountValue);
                }
            }
            // File.WriteAllBytes()


            SaveIndexFile();
            lblMessage.Text = "The file(s) have been uploaded,you can proceed for searching ";
            lblMessage.ForeColor = Color.Green;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lnkConditionalSearch_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            searchBox objSearchBox = new searchBox();
            objSearchBox.ShowDialog();
            PerformConditionalSearch();
        }

        private void PerformConditionalSearch()
        {
            if (sSearhExact == "EXACT")
            {
                if (sSearchType == "AND")
                {
                    PerformAndSearch();

                }
                if (sSearchType == "OR")
                {
                    PerformOrSearch();
                }
            }
            else
            {

                if (sSearchType == "AND")
                {
                    PerformAndSearchLike();

                }
                if (sSearchType == "OR")
                {
                    //PerformOrSearchLike();
                }

            }
        }

        private void PerformOrSearch()
        {
            dgvSearchresults.DataSource = null;
            bool isFirstTime = true;
            lstFinalResults.Clear();
            List<string> tempResult = new List<string>();
            foreach (string sWord in sSearchInput)
            {
                if (dictWords.ContainsKey(sWord))
                {
                    tempResult = dictWords[sWord].Keys.ToList();
                    if (!isFirstTime)
                    {
                        lstFinalResults = lstFinalResults.Union(tempResult).ToList();
                    }
                    else
                    {
                        lstFinalResults = new List<string>(tempResult);
                    }
                    isFirstTime = false;
                }
            }

            var list = new BindingList<string>(lstFinalResults);
            if (lstFinalResults.Count() > 0)
            {

                var columns = from t in lstFinalResults
                              select new
                              {
                                  KEY = t,
                              };
                dgvSearchresults.DataSource = columns.ToList();
                dgvSearchresults.Columns[0].HeaderText = "File Name";
            }
            else
            {
                MessageBox.Show("No Matching Results");
            }
        }

        //private void PerformOrSearchLike()
        //{
        //    dgvSearchresults.DataSource = null;
        //    bool isFirstTime = true;
        //    lstFinalResults.Clear();
        //    List<string> tempResult = new List<string>();
        //    foreach (string sWord in sSearchInput)
        //    {

        //        Dictionary<string,Dictionary<string,int>> result = dictWords.All(dict => dict.Key.Contains(sWord));
        //        resul
        //       // tempResult = dictResults.Any()(dict =>)
        //        if (!isFirstTime)
        //        {
        //            lstFinalResults = lstFinalResults.Union(tempResult).ToList();
        //        }
        //        else
        //        {
        //            lstFinalResults = new List<string>(tempResult);
        //        }
        //        isFirstTime = false;

        //    }

        //    var list = new BindingList<string>(lstFinalResults);
        //    if (lstFinalResults.Count() > 0)
        //    {

        //        var columns = from t in lstFinalResults
        //                      select new
        //                      {
        //                          KEY = t,
        //                      };
        //        dgvSearchresults.DataSource = columns.ToList();
        //        dgvSearchresults.Columns[0].HeaderText = "File Name";
        //    }
        //    else
        //    {
        //        MessageBox.Show("No Matching Results");
        //    }
        //}

        private void PerformAndSearch()
        {
            dgvSearchresults.DataSource = null;
            bool isFirstTime = true;
            lstFinalResults.Clear();
            List<string> tempResult = new List<string>();
            foreach (string sWord in sSearchInput)
            {
                if (dictWords.ContainsKey(sWord))
                {
                    tempResult = dictWords[sWord].Keys.ToList();
                    if (!isFirstTime)
                    {
                        lstFinalResults = lstFinalResults.Intersect(tempResult).ToList();
                    }
                    else
                    {
                        lstFinalResults = new List<string>(tempResult);
                    }
                    isFirstTime = false;
                }
                else
                {
                    MessageBox.Show("No Matching results");
                    return;
                }
            }

            var list = new BindingList<string>(lstFinalResults);
            if (lstFinalResults.Count() > 0)
            {

                var columns = from t in lstFinalResults
                              select new
                              {
                                  KEY = t,
                              };
                dgvSearchresults.DataSource = columns.ToList();
                dgvSearchresults.Columns[0].HeaderText = "File Name";

            }
            else
            {
                MessageBox.Show("No Matching Results");
            }
        }

        private void PerformAndSearchLike()
        {
            dgvSearchresults.DataSource = null;
            bool isFirstTime = true;
            lstFinalResults.Clear();
            List<string> tempResult = new List<string>();
            foreach (string sWord in sSearchInput)
            {
                if (



                    dictWords.Keys.Contains(sWord)) 
                {
                    tempResult = dictWords.Keys.Where(key => key.Contains(sWord)).ToList();
                    if (!isFirstTime)
                    {
                        lstFinalResults = lstFinalResults.Intersect(tempResult).ToList();
                    }
                    else
                    {
                        lstFinalResults = new List<string>(tempResult);
                    }
                    isFirstTime = false;
                }
                else
                {
                    MessageBox.Show("No Matching results");
                    return;
                }
            }

            var list = new BindingList<string>(lstFinalResults);
            if (lstFinalResults.Count() > 0)
            {

                var columns = from t in lstFinalResults
                              select new
                              {
                                  KEY = t,
                              };
                dgvSearchresults.DataSource = columns.ToList();
                dgvSearchresults.Columns[0].HeaderText = "File Name";

            }
            else
            {
                MessageBox.Show("No Matching Results");
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string sFileName = string.Empty;
            FolderBrowserDialog openFileDialog = new FolderBrowserDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                sSelectedFolder = openFileDialog.SelectedPath;
                lnkLabelFolder.Text = sSelectedFolder;

                lnkLabelFolder.AutoSize = true;
                btnUpload.Enabled = true;


                btnUploadFolder.Enabled = true;
            }
            else
            {
                btnUploadFolder.Enabled = false;
            }
        }

        private void btnUploadFolder_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "The File(s) are being scanned, please wait";
            lblMessage.ForeColor = Color.Red;
            lblMessage.Visible = true;
            DirectoryInfo dInfo = new DirectoryInfo(sSelectedFolder);
            FileInfo[] files = dInfo.GetFiles("*.txt");
            foreach (FileInfo fs in files)
            {
                string[] contents = SplitWords(System.IO.File.ReadAllText(fs.FullName.ToString()));
                Dictionary<string, int> dictFileName = new Dictionary<string, int>();
                var wordsCounts = from word in contents
                                  group word by word.ToLower()
                                   into g
                                  select new { Word = g.Key, Count = g.Count() };
                Dictionary<string, int> dictFileWords = wordsCounts.ToDictionary(wc => wc.Word, wc => wc.Count);
                foreach (string sWord in dictFileWords.Keys)
                {
                    int iCountValue = dictFileWords[sWord];
                    if (!dictWords.ContainsKey(sWord))
                    {

                        dictFileName = new Dictionary<string, int>();
                        dictFileName.Add(fs.Name, iCountValue);
                        dictWords.Add(sWord, dictFileName);
                    }
                    else
                    {
                        dictWords[sWord].Add(fs.Name, iCountValue);
                    }
                }
            }
            // File.WriteAllBytes()


            SaveIndexFile();
            lblMessage.Text = "The file(s) have been uploaded,you can proceed for searching ";
            lblMessage.ForeColor = Color.Green;
        }
    }
}
